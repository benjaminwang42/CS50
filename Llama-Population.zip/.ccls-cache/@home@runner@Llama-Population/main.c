/*
Task: Say we have a population of n llamas. Each year, n / 3 new llamas are born, and n / 4 llamas pass away.

Output the number of years it takes to go from the input starting population to the input ending population.*/ 

#include <stdio.h>

int main(void) {
  int startpop = 0;
  int endpop = 0;
  int years = 0;

  do
    {
      printf("Enter starting population: ");
      scanf("%d", &startpop);
    }
  while (startpop < 9);

  do
    {
      printf("Enter ending population: ");
      scanf("%d", &endpop);
    }
  while (endpop < startpop);
  
  do 
    {
      startpop = startpop - startpop/4 + startpop/3;
      years++;
    }
  while (startpop < endpop);

  printf("Years: %d", years);
    
  return 0;
}